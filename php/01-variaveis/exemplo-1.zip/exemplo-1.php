<?php

$nome = "Hcode";

//echo $nome;

var_dump($nome);

?>