<?php

//include "inc/exemplo-1.php";
require_once "inc/exemplo-1.php";

$resultado = somar(10, 25);

echo $resultado;

?>