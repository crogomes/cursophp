<?php

$nome = "Hcode";

echo $nome . " mais alguma coisa<br>";

$nome .= "Treinamentos";

echo $nome;

?>