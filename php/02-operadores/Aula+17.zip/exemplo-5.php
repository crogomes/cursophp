<?php

$a = 50;

$b = 35;

var_dump($a <=> $b);

echo "<br>";

$a = 35;

$b = 35;

var_dump($a <=> $b);

echo "<br>";

$a = 50;

$b = 60;

var_dump($a <=> $b);

?>