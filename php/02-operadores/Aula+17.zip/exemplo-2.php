<?php

$valorTotal = 0;

$valorTotal += 100;

$valorTotal += 25;

//$valorTotal += -10;

$valorTotal *= .9;

echo $valorTotal;

?>