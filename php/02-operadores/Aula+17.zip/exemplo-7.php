<?php

$a = 10;

echo ++$a;

echo "<br>";

echo $a;

echo "<br>";

echo --$a;

?>