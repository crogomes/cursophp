<?php

$a = NULL;

$b = 8;

$c = 10;

echo $a ?? $b ?? $c;

?>